jQuery(document).ready(function($) {	
	jQuery( ".value_date_custom" ).datepicker();
});